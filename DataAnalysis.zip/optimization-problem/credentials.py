SECRET: str = "ZkU53cBmj5tjDUkG"
KEY: str = "YOuli3psu17DIBQN6UyGr8fxhDPj4f9K"